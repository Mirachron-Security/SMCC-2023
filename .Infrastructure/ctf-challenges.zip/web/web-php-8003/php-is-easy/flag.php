<?php
$flag="flag{byp455_7h3_c0mp4r4710n}";
?>
