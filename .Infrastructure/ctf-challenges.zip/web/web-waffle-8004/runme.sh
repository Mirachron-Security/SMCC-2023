#!/bin/bash

# To build
# docker build -t web-waffle-8004 .

docker run -d -p 8004:8004 --rm -e AUTHOR="Radu" --hostname="web-waffle-8004" --name "web-waffle-8004" -it "web-waffle-8004"
