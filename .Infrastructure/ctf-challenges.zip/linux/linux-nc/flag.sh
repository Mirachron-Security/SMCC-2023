#!/bin/bash

echo "Nothing to see here... sorry"
sleep 1
echo "CTRL+C to exit the program"
sleep 5
echo "You are learning. Good."
echo "There is your flag: flag{nc_adventures}"

