#!/bin/bash

socat tcp-listen:5001,fork exec:./flag.sh
