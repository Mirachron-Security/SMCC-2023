#!/bin/bash

## To buid
# docker build --rm -t linux-ali .

docker run -d -p 5000:22 --rm --hostname "linux-ali" --name "linux-ali" -it linux-ali

## Connect
# ssh user@localhost -p5000
