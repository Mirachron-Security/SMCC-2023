#!/bin/bash

# To build
# docker build -t web5-echo .

# 8005 outside, 80 inside
docker run -d -p 8005:80 -e AUTHOR="Radu" --name "web5" -it "web5-echo"
