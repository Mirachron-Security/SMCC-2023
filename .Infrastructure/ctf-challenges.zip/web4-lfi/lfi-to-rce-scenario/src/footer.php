

<?php
/**
 * Created by PhpStorm.
 * User: moein
 * Date: 12/12/18
 * Time: 1:43 PM
 */
?>
<link rel="stylesheet" href="static/css/bootstrap.min.css">
<link rel="stylesheet" href="static/css/font-awesome.min.css">
<div class="footer text-center navbar-fixed-bottom">
    <hr>
    <div class="logo">
        <a href="https://twitter.com/MoeinFatehi" title="Twitter" target="_blank"><i class="fa fa-twitter-square fa-3x twitter-icon"></i></a>
        <a href="https://github.com/moeinfatehi" title="Github" target="_blank"><i class="fa fa-github-square fa-3x github-icon"></i></a>
        <a href="https://www.linkedin.com/in/moein-fatehi-87a35936/" title="Linkedin" target="_blank"><i class="fa fa-linkedin-square fa-3x linkedin-icon"></i></a>
    </div>
    <p>If you need the solutions, follow <a href="https://twitter.com/MoeinFatehi">@MoeinFatehi</a> on twitter and ask for cheat sheet.</p>
</div>