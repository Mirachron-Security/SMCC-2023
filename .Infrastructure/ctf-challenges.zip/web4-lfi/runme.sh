#!/bin/bash

# To build
# docker build -t web4-lfi .

docker run -d -p 8004:80 --rm -e AUTHOR="Radu" --name "web4" -it "web4-lfi"
